<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `admit_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:admit_updates.php');

?>