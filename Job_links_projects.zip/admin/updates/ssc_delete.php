<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `ssc_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:ssc_updates.php');

?>