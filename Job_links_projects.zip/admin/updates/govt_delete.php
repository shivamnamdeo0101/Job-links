<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `govt_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:govt_updates.php');

?>