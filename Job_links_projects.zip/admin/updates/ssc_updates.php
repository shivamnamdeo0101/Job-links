
<!------------------------------------------------------------SESION------------------------------------------->

<?php
    session_start();

    if(isset($_SESSION['User']))
    {
        echo ' <h2>Well Come ' . $_SESSION['User'].'<br/></h2>';
        echo '<a href="/admin/logout.php?logout"><input type="submit" value="Logout"></a><br/><br/>';
    }
    else
    {
        header("location:index.php");
    }

?>
<!------------------------------------------------------------SESION------------------------------------------->



<!DOCTYPE html>
<html>
<head>
 

	<title>Admin | SSC Jobs Updates</title>
	<link rel="stylesheet" type="text/css" href="/admin/updates/bootstrap.css">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

		
	
  
</head>
<body>

	<nav class="navbar navbar-default">
		<div class="container">
			<a class="navbar-brand" href="/admin/wellcome.php" >Back</a>
			<h3 align="center"><b>SSC Jobs Updates</b></h3>
		</div>
	</nav>




<!-------------------------------------------FORM---------------------------->



	
<form action="ssc_insert.php" method="post">
    <table class="w3-table-all">
   <tr>
    <td> 1.Job Title </td>
    <td><input type="text" name="job_title" required></td>
   </tr>
   <tr>
    <td>2.Post Name</td>
    <td><input type="text" name="post_name" required></td>
   </tr> 
    <tr>
    <td>3.Eligibility</td>
    <td><input type="text" name="elg" required></td>
   </tr> 
   <tr>
    <td>4.Start Date</td>
    <td><input type="date" name="start_date" required></td>
   </tr>
   <tr>
    <td>5.Last Date</td>
    <td><input type="date" name="last_date" required></td>
   </tr>
   <tr>
    <td>6.Posts</td>
    <td><input type="number" name="quantity" required></td>
   </tr>
    <tr>
    <td>7.Fees</td>
    <td><input type="text" name="fees" required></td>
   </tr>
   <tr>
    <td>8.Official Wesite</td>
    <td><input type="text" name="website" required></td>
   </tr>
   <tr>
    <td>9. Notification +syllabus</td>
    <td><input type="text" name="notice" required></td>
   </tr>
   <tr>
    <td><input type="submit" value="Submit" class="btn btn-primary"></td><td></td>
   </tr>
  </table>
</form>


<!---------------------------------------------  FORM---------------------------->

<!--------------------------------------------TABLE ---------------------------------------->

  <div>
 <div>
 
 <table  class="w3-table-all">
 
 <tr>
  <th>S. No.</th> 
  <th>Job Title</th> 
  <th>Post Name</th> 
  <th>Eligibility</th>
  <th>Start Date</th> 
  <th>Last Date</th> 
  <th>Posts</th> 
  <th>Fees</th> 
  <th>official Website</th> 
  <th>Notification Download</th> 
  <th>Delete</th> 

 </tr >

  <?php

  include 'conn.php'; 
 $q = "select * from ssc_updates ";

  $query = mysqli_query($con,$q);

$count=0;

  while($res = mysqli_fetch_array($query)){$count++;
 ?>
 <tr>
<td> <?php echo $count; ?> </td>
 <td> <?php echo $res['job_title'];  ?> </td>
 <td> <?php echo $res['post_name'];  ?> </td>
 <td> <?php echo $res['elg'];  ?> </td>
 
 <td> <?php echo $res['start_date'];  ?> </td>
 <td> <?php echo $res['last_date'];  ?> </td>
 <td> <?php echo $res['quantity'];  ?> </td>
 <td> <?php echo $res['fees'];  ?> </td>
  

 <td> <a href="<?php echo $res['website'];  ?>"><input type="submit" value="Click Here" class="btn btn-primary"></a> </td>
  <td> <a href="<?php echo $res['notice'];  ?>"><input type="submit" value="Click Here" class="btn btn-primary"></a> </td>
  
 <td> <a href="ssc_delete.php?id=<?php echo $res['id']; ?>" ><input type="submit" value="Delete" class="btn btn-danger"></a>  </td>

 </tr>

  <?php 
 }
  ?>
 
 </table>  

  </div>
 </div>

  <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>


<!--------------------------------------------TABLE  --------------------------------------->

<br><br>
</body>
</html>