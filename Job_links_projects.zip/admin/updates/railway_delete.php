<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `railway_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:railway_updates.php');

?>