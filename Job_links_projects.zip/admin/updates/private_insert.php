<?php


include 'connection.php';

$job_title = $_POST['job_title'];
$post_name = $_POST['post_name'];
$elg = $_POST['elg'];

$start_date = $_POST['start_date'];
$last_date = $_POST['last_date'];
$fees = $_POST['fees'];
$website = $_POST['website'];
$notice = $_POST['notice'];
$quantity = $_POST['quantity'];



$sql = "INSERT INTO private_updates (job_title,post_name,elg,start_date,last_date,fees,website,notice,quantity)
VALUES ('$job_title', '$post_name','$elg', '$start_date', '$last_date', '$fees', '$website', '$notice' , '$quantity');";


if ($conn->multi_query($sql) === TRUE) {



    echo "<script>window.location='private_updates.php'</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
