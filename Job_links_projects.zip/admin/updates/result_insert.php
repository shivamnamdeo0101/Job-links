<?php


include 'connection.php';

$discription = $_POST['discription'];
$link = $_POST['link'];
$date = $_POST['date'];


$sql = "INSERT INTO result_updates (link,discription,date)
VALUES ('$link', '$discription','$date');";


if ($conn->multi_query($sql) === TRUE) {



    echo "<script>window.location='result_updates.php'</script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
