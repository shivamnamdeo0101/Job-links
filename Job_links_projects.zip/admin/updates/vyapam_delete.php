<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `vyapam_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:vyapam_updates.php');

?>