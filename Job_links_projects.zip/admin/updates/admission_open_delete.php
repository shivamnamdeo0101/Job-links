<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `admission_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:admission_open_updates.php');

?>