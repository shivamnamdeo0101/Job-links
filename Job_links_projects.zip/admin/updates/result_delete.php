<?php

include 'conn.php';

$id = $_GET['id'];

$q = " DELETE FROM `result_updates` WHERE id = $id ";

mysqli_query($con, $q);

header('location:result_updates.php');

?>