
<!------------------------------------------------------------SESION------------------------------------------->

<?php
    session_start();

    if(isset($_SESSION['User']))
    {
        echo ' <font size="5">Well Come  ' . $_SESSION['User'].'<br/>  </font>';
        echo '<a href="logout.php?logout"><input type="submit" value="Logout"></a><br/><br/>';
    }
    else
    {
        header("location:index.php");
    }

?>
<!------------------------------------------------------------SESION------------------------------------------->

<!--------------------------------------Admin---------------------------------------------------------->
<!DOCTYPE html>
<html>
<head>
<title>ADMIN Dashboard JobLinks</title>
<link rel="icon" href="/images/logo.jpeg" type="image/gif">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">


<style>


h1,h3{
text-align:center;
}
</style>

</head>
<body bgcolor="#36c2f7">

<h2 align="center"><b>ADMIN JOBLINKS</b></h2>


<table  class="w3-table-all" >
 

<!---------------------------------------------Message-------------------------------------->


<tr><th>Message</th><th></th><th></th></tr>
<tr><td>1.</td><td> Message</td><td><a href="#"><button class="btn btn-primary">Click Here</button></a></td></tr>
<!----------------------------------------------Message----------------------------------------->


<!----------------------------------------------Admit Card-------------------------------------->


<tr><th>Admit Card</th><th></th><th></th></tr>
<tr><td>2.</td><td> Admit Card</td><td><a href="/admin/updates/admit_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>
<!----------------------------------------------Admit Card----------------------------------------->

<!-------------------------------------------Result----------------------------------------->

<tr><th>Result</th><th></th><th></th></tr>


<tr><td>3.</td><td> Result </td><td><a href="/admin/updates/result_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!-------------------------------------------NoticeUpdates----------------------------------------->


<!------------------------------------------Govt Jobs----------------------------------------->

<tr><th>Govt. Jobs </th><th></th><th></th></tr>


<tr><td>4.</td><td> Govt. Jobs</td><td><a href="/admin/updates/govt_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!-------------------------------------------Govt. Jobs----------------------------------------->


<!-------------------------------------------Private Jobs----------------------------------------->

<tr><th>Private Jobs </th><th></th><th></th></tr>


<tr><td>5.</td><td> Private Jobs</td><td><a href="/admin/updates/private_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!-------------------------------------------Private Jobs----------------------------------------->


<!-------------------------------------------Defence Jobs----------------------------------------->

<tr><th>Defence Jobs </th><th></th><th></th></tr>


<tr><td>6.</td><td> Defence Jobs</td><td><a href="/admin/updates/defence_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!-------------------------------------------Defence Jobs----------------------------------------->


<!------------------------------------------Vyapam Jobs----------------------------------------->

<tr><th>Vyapam Jobs </th><th></th><th></th></tr>


<tr><td>7.</td><td>Vyapam Jobs</td><td><a href="/admin/updates/vyapam_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!--------------------------------------------Vyapam Jobs----------------------------------------->


<!------------------------------------------SSC Jobs----------------------------------------->

<tr><th>SSC Jobs </th><th></th><th></th></tr>


<tr><td>8.</td><td>SSC Jobs</td><td><a href="/admin/updates/ssc_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!--------------------------------------------SSC Jobs----------------------------------------->

<!------------------------------------------Railway Jobs----------------------------------------->

<tr><th>Railway Jobs </th><th></th><th></th></tr>


<tr><td>9.</td><td>Railway Jobs</td><td><a href="/admin/updates/railway_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!--------------------------------------------Railway Jobs----------------------------------------->

<!-----------------------------------------Admission Open----------------------------------------->

<tr><th>Admission Open</th><th></th><th></th></tr>


<tr><td>10.</td><td>Admission Open</td><td><a href="/admin/updates/admission_open_updates.php"><button class="btn btn-primary">Click Here</button></a></td></tr>


<!-------------------------------------------Admission Open----------------------------------------->


</table> 

<br><br><br><br><br>   
</body>
</html> 

<!--------------------------------------FUll TAB MENU---------------------------------------------------------->

