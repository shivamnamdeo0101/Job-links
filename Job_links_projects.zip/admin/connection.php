<?php

    $con=mysqli_connect('localhost','id9689372_cs','123456','id9689372_cs');

    if(!$con)
    {
        die(' Please Check Your Connection'.mysqli_error($con));
    }
?>