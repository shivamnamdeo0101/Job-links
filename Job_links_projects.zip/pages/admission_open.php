
<html>

<head>

<title>JOB_LINKS | Admission Open</title>

<link rel="icon" href="/images/logo.jpeg" type="image/gif">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">

<style>
h1,h4{

text-align:center;
color:#ad57ff;
font-weight:bold;
}
p{
   color:#FF0000; 
    
}
</style>	
</head>


<body>


<!---------------------------------------Body----------------------------------------------------------------->


<!--------------------------------------------nav Login------------------------------------------------>

<!-- logo and login -->
<nav class="navbar navbar-light bg-light">
  <a class="navbar-brand" href="/admin/index.php">
    <img src="/images/logo.jpeg" width="30" height="30" class="d-inline-block align-top" alt="JOB_LINK">
    Login
  </a>
  <a class="navbar-brand" href="#"> Conatct Us :example@mail.com ,Mobile No : 9999999999</a>

</nav>

<!------------------------------------------Nav Login------------------------------------------------>

<!--------------------------------------------------Header---------------------------------------------->
<center>
<br>
<h1> JOBLINKS.COM </h1>
<p>Find Your Job</p>
<img src="/images/banner.jpeg" style="width:100%;height:25%">
<br>
</center>
<!--------------------------------------------------Header---------------------------------------------->

<!-----------------------------------------------------NAV BAR-------------------------------------------->

<nav class="navbar navbar-light bg-light">
	<a class="navbar-brand" href="/index.php"><button type="button" class="btn btn-secondary">Home</button></a>
	<a class="navbar-brand" href="/pages/admit_card.php"><button type="button" class="btn btn-secondary">Admit Card</button></a>
	<a class="navbar-brand" href="/pages/result.php"><button type="button" class="btn btn-secondary">Result</button></a>
	<a class="navbar-brand" href="/pages/govt_jobs.php"><button type="button" class="btn btn-secondary">Govt.Jobs</button></a>
	<a class="navbar-brand" href="/pages/private_jobs.php"><button type="button" class="btn btn-secondary">Private Jobs</button></a>
	<a class="navbar-brand" href="/pages/defence_jobs.php"><button type="button" class="btn btn-secondary">Defence Jobs</button></a>
	<a class="navbar-brand" href="/pages/vyapam_jobs.php"><button type="button" class="btn btn-secondary">Vypam Jobs</button></a>
	<a class="navbar-brand" href="/pages/ssc_jobs.php"><button type="button" class="btn btn-secondary">SSC Jobs</button></a>
	<a class="navbar-brand" href="/pages/railway_jobs.php"><button type="button" class="btn btn-secondary">Railway Jobs</button></a>
	<a class="navbar-brand" href="#"><button type="button" class="btn btn-secondary">Admission Open</button></a>

	
</nav>
<!---------------------------------------------NAV BAR------------------------------------------------>





<!--------------------------------------------TABLE ADMISSION---------------------------------------->

  <div>
 <div>
 <h4>ADMISSION UPDATES</h4>
 <table  class="w3-table-all">
 
 <tr>
  <th>S. No.</th> 
  <th>Title</th> 
  <th>College Name</th> 
  <th>Eligibilty</th>
  <th>Start Date</th> 
  <th>Last Date</th> 
  <th>Seats</th> 
  <th>Fees</th> 
  <th>Official Website</th> 
  <th>Notification + syllabus</th> 
 
 </tr >

  <?php

  include 'conn.php'; 
 $q = "select * from admission_updates ";

  $query = mysqli_query($con,$q);

$count=0;

  while($res = mysqli_fetch_array($query)){$count++;
 ?>
 <tr>
<td> <?php echo $count; ?> </td>
 <td> <?php echo $res['job_title'];  ?> </td>
 <td> <?php echo $res['post_name'];  ?> </td>
 <td> <?php echo $res['elg'];  ?> </td>
 <td> <?php echo $res['start_date'];  ?> </td>
 <td> <?php echo $res['last_date'];  ?> </td>
 <td> <?php echo $res['quantity'];  ?> </td>
 <td> <?php echo $res['fees'];  ?> </td>
  

 <td> <a href="<?php echo $res['website'];  ?>"><input type="submit" value="Click Here" class="btn btn-secondary btn-sm"></a> </td>
  <td> <a href="<?php echo $res['notice'];  ?>"><input type="submit" value="Click Here" class="btn btn-secondary btn-sm"></a> </td>
  

 </tr>

  <?php 
 }
  ?>
 
 </table>  

  </div>
 </div>

  <script type="text/javascript">
 
 $(document).ready(function(){
 $('#tabledata').DataTable();
 }) 
 
 </script>


<!--------------------------------------------TABLE ADMISSION--------------------------------------->















<!---------------------------------------Body--------------------------------------->
<br><br>

<!--------------------------------------------Footer------------------------------------->

<div class="w3-container w3-grey">
  
<center>
<br><br>
<font color="white">
Contents on this website is published and maintained by JOBLINKS.COM<br>
Copyright &copy; 2019 JOBLINKS.COM<br>
 All Rights Reserved
</font>

</center>
<br>
</div>
<br><br>
<!---------------------------------------FOOter--------------------------------------------->
</body>
</html>