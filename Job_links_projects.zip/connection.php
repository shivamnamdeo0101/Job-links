<?php

$servername = "localhost";
$username = "id9689372_cs";
$password = "123456";
$dbname = "id9689372_cs";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

?>