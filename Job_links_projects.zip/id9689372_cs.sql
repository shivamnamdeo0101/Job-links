-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: May 26, 2019 at 04:02 PM
-- Server version: 10.3.14-MariaDB
-- PHP Version: 7.3.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `id9689372_cs`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `E_id` int(50) NOT NULL,
  `UName` varchar(255) NOT NULL,
  `Pass` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`E_id`, `UName`, `Pass`) VALUES
(1, 'joblinks', '123456'),
(2, 'joblink', '123456');

-- --------------------------------------------------------

--
-- Table structure for table `admission_updates`
--

CREATE TABLE `admission_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admission_updates`
--

INSERT INTO `admission_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(3, 'TCS COMPANY', 'Programmer', '', '2019-02-01', '2019-02-01', 50, '500', 'https://www.google.com/', 'https://www.google.com/'),
(4, 'polytechnic collage daomh', 'ppt exam', '', '2019-05-31', '2019-06-28', 300, '250', 'rgvpdiploma.com', 'www.mponline.gov.in');

-- --------------------------------------------------------

--
-- Table structure for table `admit_updates`
--

CREATE TABLE `admit_updates` (
  `id` int(11) NOT NULL,
  `discription` text NOT NULL,
  `date` date NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admit_updates`
--

INSERT INTO `admit_updates` (`id`, `discription`, `date`, `link`) VALUES
(9, 'GOOGLE', '2019-02-01', 'https://www.google.com/'),
(10, 'CCC Admit Card May 2019', '2019-05-18', 'https://student.nielit.gov.in/');

-- --------------------------------------------------------

--
-- Table structure for table `defence_updates`
--

CREATE TABLE `defence_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `defence_updates`
--

INSERT INTO `defence_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(2, 'navy', 'Indian Navy MR Music Online Form 2019', '', '2019-05-06', '2019-05-19', 100, '0', 'https://www.joinindiannavy.gov.in/', 'https://www.joinindiannavy.gov.in/'),
(3, 'TCS COMPANY defence', 'Programmer', '12th', '2019-02-01', '2019-02-01', 500, '500', 'https://www.google.com/', 'https://www.google.com/'),
(4, 'TCS COMPANY Private', 'Programmer', '12th', '2019-05-08', '2019-05-09', 500, '500', 'https://www.google.com/', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `govt_updates`
--

CREATE TABLE `govt_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `govt_updates`
--

INSERT INTO `govt_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(7, 'Govt job', 'Railway ', '', '2019-05-24', '2019-06-21', 600, '250', 'http://pbicf.gov.in/index.php', 'http://pbicf.gov.in/index.php'),
(8, 'Railway ', 'Railway ICF Chennai Apprentice Online', '', '2019-05-20', '2019-06-26', 942, '100', 'http://pbicf.gov.in/app_mainpage', 'http://pbicf.gov.in/app2019notification.pdf'),
(10, 'TCS COMPANY GOVT', 'Programmer', '12th', '2109-10-20', '2019-10-20', 500, '500', 'https://www.google.com/', 'https://www.google.com/'),
(11, 'govt job', 'NFL Management Trainee Online Form 2019', 'mba ,bsc', '2019-05-15', '2019-06-06', 44, '700', 'http://www.nationalfertilizers.com/index.php?option=com_content&view=article&id=344&Itemid=123', 'http://www.nationalfertilizers.com/images/pdf/career/noida/MT%20AD%20-%20FINAL%202019.pdf'),
(12, 'Coast Guard Assistant', 'Coast Guard Assistant Commandant Online Form 2019', '12th', '2019-05-25', '2019-06-14', 800, '0', 'http://www.joinindiancoastguard.gov.in/', 'http://www.joinindiancoastguard.gov.in/'),
(13, 'Coast Guard Assistant', 'Coast Guard Assistant Commandant Online Form 2019', '12th', '2019-05-25', '2019-06-14', 800, '0', 'http://www.joinindiancoastguard.gov.in/', 'http://www.joinindiancoastguard.gov.in/');

-- --------------------------------------------------------

--
-- Table structure for table `private_updates`
--

CREATE TABLE `private_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `private_updates`
--

INSERT INTO `private_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(3, 'Web Designer ', 'Web Designer & Developer', '', '2019-05-16', '2019-06-01', 40, '0', 'https://www.indeed.co.in/jobs?q=Private%20Company&l=jabalpur&advn=5222681882145141&vjk=c00ae899bcf2baa1', 'https://www.indeed.co.in/jobs?q=Private%20Company&l=jabalpur&advn=5222681882145141&vjk=c00ae899bcf2baa1'),
(4, 'TCS COMPANY Private', 'Programmer', '12th', '1209-02-01', '2019-02-01', 500, '500', 'https://www.google.com/', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `railway_updates`
--

CREATE TABLE `railway_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `railway_updates`
--

INSERT INTO `railway_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(3, 'TCS COMPANY railway', 'Programmer', '12th', '2019-02-01', '2019-02-01', 500, '500', 'https://www.google.com/', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `result_updates`
--

CREATE TABLE `result_updates` (
  `id` int(50) NOT NULL,
  `discription` text NOT NULL,
  `date` date NOT NULL,
  `link` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result_updates`
--

INSERT INTO `result_updates` (`id`, `discription`, `date`, `link`) VALUES
(4, 'GOOGLE', '2019-02-01', 'https://www.google.com/'),
(5, 'GOOGLE', '2019-05-17', 'https://www.google.com/'),
(6, 'Bihar Board Class 10 Matric Scrutiny Result 2019', '2019-05-23', 'http://www.biharboardonline.in/');

-- --------------------------------------------------------

--
-- Table structure for table `ssc_updates`
--

CREATE TABLE `ssc_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(255) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ssc_updates`
--

INSERT INTO `ssc_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(4, 'ssc', 'Multi Tasking (Non-Technical) Staff Examination, 2019', '', '2019-05-02', '2019-05-29', 6000, '100', 'https://ssc.nic.in/', 'https://ssc.nic.in/'),
(5, 'TCS COMPANY SSC', 'Programmer', '12th', '2019-02-01', '2019-02-01', 500, '500', 'https://www.google.com/', 'https://www.google.com/');

-- --------------------------------------------------------

--
-- Table structure for table `vyapam_updates`
--

CREATE TABLE `vyapam_updates` (
  `id` int(255) NOT NULL,
  `job_title` text NOT NULL,
  `post_name` text NOT NULL,
  `elg` text NOT NULL,
  `start_date` date NOT NULL,
  `last_date` date NOT NULL,
  `quantity` int(11) NOT NULL,
  `fees` varchar(255) NOT NULL,
  `website` text NOT NULL,
  `notice` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vyapam_updates`
--

INSERT INTO `vyapam_updates` (`id`, `job_title`, `post_name`, `elg`, `start_date`, `last_date`, `quantity`, `fees`, `website`, `notice`) VALUES
(3, 'vyapam', 'Middle School Teacher (Middle School Sikshak Eligibility Test 2018)', '', '2019-05-23', '2019-06-22', 475, '250', 'http://peb.mp.gov.in/', 'http://peb.mp.gov.in/Middle_school_Sikshak_Eligibilty_test_2108.pdf'),
(4, 'TCS COMPANY vyapam', 'Programmer', '12th', '2109-02-01', '2019-02-01', 500, '500', 'https://www.google.com/', 'https://www.google.com/');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`E_id`);

--
-- Indexes for table `admission_updates`
--
ALTER TABLE `admission_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admit_updates`
--
ALTER TABLE `admit_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `defence_updates`
--
ALTER TABLE `defence_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `govt_updates`
--
ALTER TABLE `govt_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `private_updates`
--
ALTER TABLE `private_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `railway_updates`
--
ALTER TABLE `railway_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `result_updates`
--
ALTER TABLE `result_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ssc_updates`
--
ALTER TABLE `ssc_updates`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vyapam_updates`
--
ALTER TABLE `vyapam_updates`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `E_id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admission_updates`
--
ALTER TABLE `admission_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admit_updates`
--
ALTER TABLE `admit_updates`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `defence_updates`
--
ALTER TABLE `defence_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `govt_updates`
--
ALTER TABLE `govt_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `private_updates`
--
ALTER TABLE `private_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `railway_updates`
--
ALTER TABLE `railway_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `result_updates`
--
ALTER TABLE `result_updates`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ssc_updates`
--
ALTER TABLE `ssc_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `vyapam_updates`
--
ALTER TABLE `vyapam_updates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
